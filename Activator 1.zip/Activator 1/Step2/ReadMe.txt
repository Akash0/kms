Downloaded from igetintopc.com
Visit Us Daily. Have a nice day
Michelle Williams
igetintopc.com

1. Copy this folder to your desktop (very important) Disable all your antivurs and windows defender(very important)
2. Install office 2019 after completing installation don’t launch anything.
3. Go to step 1 folder and run Convert-C2R.cmd and wait for the process to complete.
4. Open step 2 folder and run KMS-VL-ALL.cmd, allow it sometime all will be done automatically
5. Now remember we at igetintopc.com take care all your requests don’t forget to refer us to your loved ones.

if you have not disabled your antivirus or windows defender do not expect that office will be activated perfectly fine.
it is activated for life time so Yes you can upgrade it any time for life time.

Downloaded from igetintopc.com
Visit Us Daily. Have a nice day
Michelle Williams
igetintopc.com